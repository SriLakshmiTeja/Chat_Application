const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const User = require('../models/user');

// Serialize the user for session storage
passport.serializeUser((user, done) => {
  done(null, user.id);
});

// Deserialize the user for session retrieval
passport.deserializeUser((id, done) => {
  User.findById(id, (err, user) => {
    done(err, user);
  });
});

// Configure the local strategy for username and password authentication
passport.use(new LocalStrategy(User.authenticate()));

module.exports = passport;
