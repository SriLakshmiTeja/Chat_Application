const mongoose = require('mongoose');

const dbURL = 'mongodb://localhost:27017/chat_app_db';

mongoose.connect(dbURL, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const db = mongoose.connection;

db.on('error', (err) => {
  console.error(`Database connection error: ${err}`);
});

db.on('connected', () => {
  console.log('Connected to the database');
});

module.exports = db;
