const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const passport = require('passport');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const messagesRoutes = require('./routes/messages');
const groupsRoutes = require('./routes/groups');
const chatbotRoutes = require('./routes/chatbot');

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to your MongoDB database
mongoose.connect('mongodb://localhost/chat_app_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Middleware
app.use(express.json());
app.use(session({ secret: 'your-secret-key', resave: false, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());

// Include your passport configuration (backend/config/passport.js)

// Routes
app.use('/auth', authRoutes);
app.use('/messages', messagesRoutes);
app.use('/groups', groupsRoutes);
app.use('/chatbot', chatbotRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
