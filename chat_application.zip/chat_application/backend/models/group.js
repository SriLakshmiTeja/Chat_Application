const mongoose = require('mongoose');

const groupSchema = new mongoose.Schema({
  name: String,
  members: [String], // Array of usernames or user IDs for group members
  // You can add more fields as needed, such as group description, group profile picture, etc.
});

const Group = mongoose.model('Group', groupSchema);

module.exports = Group;
