const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  text: String,
  sender: String, // Username or user ID of the message sender
  chatId: String, // Identifier for the chat the message belongs to
  // You can add more fields as needed, such as message timestamp, attachments, reactions, etc.
});

const Message = mongoose.model('Message', messageSchema);

module.exports = Message;
