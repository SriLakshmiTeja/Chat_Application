import React, { useState } from 'react';
import MyMessage from './MyMessage';
import TheirMessage from './TheirMessage';
import MessageForm from './MessageForm';
import LogoutButton from './LogoutButton';


const ChatFeed = (props) => {
  const { chats, activeChat, userName, messages } = props;
  const chat = chats && chats[activeChat];
  const loggedUser = localStorage.getItem('username'); // Get the logged-in user

  const userContainerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  };

  const logoutButtonContainerStyle = {
    marginLeft: 'auto', // Push the button to the right
  };

  const renderReadReceipts = (message) => {
    const isMyMessage = userName === message.sender.username;
  
    if (isMyMessage) {
      return chat.people.map((person, index) => {
        return person.last_read === message.id && (
          <div
            key={`read_${index}`}
            className="read-receipt"
            style={{
              float: 'right',
              backgroundImage: person.person.avatar && `url(${person.person.avatar})`,
            }}
          />
        );
      });
    }
    return null;
  };  
  
  
  const renderMessages = () => {
    const keys = Object.keys(messages);
  
    return keys.map((key, index) => {
      const message = messages[key];
      const lastMessageKey = index === 0 ? null : keys[index - 1];
      const isMyMessage = userName === message.sender.username;
  
      return (
        <div key={`msg_${index}`} style={{ width: '100%' }}>
          <div className="message-block">
            {isMyMessage
              ? <MyMessage message={message} />
              : <TheirMessage message={message} lastMessage={messages[lastMessageKey]} />}
          </div>
          <div className="read-receipts" style={{ marginRight: isMyMessage ? '0px' : '18px', marginLeft: isMyMessage ? '68px' : '0px' }}>
            {renderReadReceipts(message)}
          </div>
        </div>
      );
    });
  };
  
  

  if (!chat) return <div />;

  return (
    <div className="chat-feed">
      <div className="chat-title-container">
        <div className="chat-title">{chat?.title}</div>
        <div className="chat-subtitle">
          {chat.people.map((person) => ` ${person.person.username}`)}
        </div>
      </div>
      {renderMessages()}
      <div style={{ height: '100px' }} />
      <div className="message-form-container">
        <MessageForm {...props} chatId={activeChat} />
        {loggedUser && (
          <div style={userContainerStyle}>
            <p>Logged in as: {loggedUser}</p>
            <div style={logoutButtonContainerStyle}>
              <LogoutButton />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};


export default ChatFeed;
