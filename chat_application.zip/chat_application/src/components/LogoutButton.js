import React from 'react';

const LogoutButton = () => {
  const handleLogout = () => {
    // Clear the stored username and password
    localStorage.removeItem('username');
    localStorage.removeItem('password');
    window.location.href = '/login';

    // Redirect to the login page or perform any other necessary actions
    // Example: window.location.href = '/login';
  };

  return (
    <div>
      <button onClick={handleLogout} className="logout-button">
        Logout
      </button>
    </div>
  );
};

export default LogoutButton;